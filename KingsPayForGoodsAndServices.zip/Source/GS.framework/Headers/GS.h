//
//  GS.h
//  GS
//
//  Created by Damian Kolasiński on 29/06/2020.
//

#import <Foundation/Foundation.h>

//! Project version number for GS.
FOUNDATION_EXPORT double GSVersionNumber;

//! Project version string for GS.
FOUNDATION_EXPORT const unsigned char GSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GS/PublicHeader.h>


